/*
 * XCred - Account Transparency for X/Twitter
 * Copyright (c) 2025 Will Power Media LLC. All rights reserved.
 * Unauthorized copying, distribution, or modification is prohibited.
 * https://xcred.org
 */

const XLocationFlags = {

  FLAG_CDN_BASE: 'https://purecatamphetamine.github.io/country-flag-icons/3x2',

  getFlagUrl(countryCode) {
    if (!countryCode || countryCode.length !== 2) {
      return null;
    }

    const code = countryCode.toUpperCase();

    if (this.isRegionCode(code)) {
      return null;
    }

    const firstChar = code.charCodeAt(0);
    const secondChar = code.charCodeAt(1);
    if (firstChar < 65 || firstChar > 90 || secondChar < 65 || secondChar > 90) {
      return null;
    }

    return `${this.FLAG_CDN_BASE}/${code}.svg`;
  },

  getFlagEmoji(countryCode) {
    if (!countryCode || countryCode.length !== 2) {
      return '🌐';
    }

    const code = countryCode.toUpperCase();

    const region = this.getRegionByCode(code);
    if (region) {
      return region.emoji;
    }

    const OFFSET = 127397;

    try {
      const firstChar = code.charCodeAt(0);
      const secondChar = code.charCodeAt(1);

      if (firstChar < 65 || firstChar > 90 || secondChar < 65 || secondChar > 90) {
        return '🌐';
      }

      return String.fromCodePoint(firstChar + OFFSET, secondChar + OFFSET);
    } catch (e) {
      return '🌐';
    }
  },

  getFlag(countryCode) {
    return this.getFlagEmoji(countryCode);
  },

  regionMapping: {
    'north america': { code: 'NA', emoji: '🌎', name: 'North America' },
    'south america': { code: 'SA', emoji: '🌎', name: 'South America' },
    'latin america': { code: 'LA', emoji: '🌎', name: 'Latin America' },
    'europe': { code: 'EU', emoji: '🌍', name: 'Europe' },
    'africa': { code: 'AF', emoji: '🌍', name: 'Africa' },
    'asia': { code: 'AS', emoji: '🌏', name: 'Asia' },
    'asia pacific': { code: 'AP', emoji: '🌏', name: 'Asia Pacific' },
    'middle east': { code: 'ME', emoji: '🌍', name: 'Middle East' },
    'oceania': { code: 'OC', emoji: '🌏', name: 'Oceania' },
  },

  countryNameToCode: {
    
    'united states': 'US',
    'usa': 'US',
    'america': 'US',
    'canada': 'CA',
    'mexico': 'MX',

    'united kingdom': 'GB',
    'uk': 'GB',
    'england': 'GB',
    'scotland': 'GB',
    'wales': 'GB',
    'germany': 'DE',
    'france': 'FR',
    'italy': 'IT',
    'spain': 'ES',
    'portugal': 'PT',
    'netherlands': 'NL',
    'holland': 'NL',
    'belgium': 'BE',
    'switzerland': 'CH',
    'austria': 'AT',
    'poland': 'PL',
    'sweden': 'SE',
    'norway': 'NO',
    'denmark': 'DK',
    'finland': 'FI',
    'ireland': 'IE',
    'greece': 'GR',
    'czech republic': 'CZ',
    'czechia': 'CZ',
    'romania': 'RO',
    'hungary': 'HU',
    'ukraine': 'UA',
    'russia': 'RU',
    'russian federation': 'RU',

    'china': 'CN',
    'japan': 'JP',
    'south korea': 'KR',
    'korea': 'KR',
    'india': 'IN',
    'indonesia': 'ID',
    'thailand': 'TH',
    'vietnam': 'VN',
    'philippines': 'PH',
    'malaysia': 'MY',
    'singapore': 'SG',
    'pakistan': 'PK',
    'bangladesh': 'BD',
    'taiwan': 'TW',
    'hong kong': 'HK',

    'israel': 'IL',
    'saudi arabia': 'SA',
    'united arab emirates': 'AE',
    'uae': 'AE',
    'turkey': 'TR',
    'türkiye': 'TR',
    'iran': 'IR',
    'islamic republic of iran': 'IR',
    'iraq': 'IQ',
    'egypt': 'EG',
    'qatar': 'QA',
    'kuwait': 'KW',
    'bahrain': 'BH',
    'oman': 'OM',
    'jordan': 'JO',
    'lebanon': 'LB',
    'syria': 'SY',
    'yemen': 'YE',

    'australia': 'AU',
    'new zealand': 'NZ',

    'brazil': 'BR',
    'argentina': 'AR',
    'colombia': 'CO',
    'chile': 'CL',
    'peru': 'PE',
    'venezuela': 'VE',

    'south africa': 'ZA',
    'nigeria': 'NG',
    'kenya': 'KE',
    'morocco': 'MA',
    'ethiopia': 'ET',
    'ghana': 'GH',
    'algeria': 'DZ',
    'tunisia': 'TN',
    'libya': 'LY',

    'belarus': 'BY',
    'kazakhstan': 'KZ',
    'uzbekistan': 'UZ',
    'georgia': 'GE',
    'armenia': 'AM',
    'azerbaijan': 'AZ',
    'moldova': 'MD',
    'serbia': 'RS',
    'croatia': 'HR',
    'bulgaria': 'BG',
    'slovakia': 'SK',
    'slovenia': 'SI',
    'lithuania': 'LT',
    'latvia': 'LV',
    'estonia': 'EE',

    'north korea': 'KP',
    'democratic people\'s republic of korea': 'KP',
    'republic of korea': 'KR'
  },

  parseLocation(location) {
    if (!location) return null;

    const normalized = location.toLowerCase().trim();

    for (const [name, regionData] of Object.entries(this.regionMapping)) {
      if (normalized === name || normalized.includes(name)) {
        return regionData.code; 
      }
    }

    for (const [name, code] of Object.entries(this.countryNameToCode)) {
      if (normalized === name || normalized.endsWith(`, ${name}`) || normalized.endsWith(` ${name}`)) {
        return code;
      }
    }

    for (const [name, code] of Object.entries(this.countryNameToCode)) {
      if (normalized.includes(name)) {
        return code;
      }
    }

    const isoMatch = normalized.match(/\b([a-z]{2})\s*$/i);
    if (isoMatch) {
      const potentialCode = isoMatch[1].toUpperCase();
      
      if (Object.values(this.countryNameToCode).includes(potentialCode)) {
        return potentialCode;
      }
    }

    return null;
  },

  isRegionCode(code) {
    if (!code) return false;
    return Object.values(this.regionMapping).some(r => r.code === code);
  },

  getRegionByCode(code) {
    if (!code) return null;
    for (const regionData of Object.values(this.regionMapping)) {
      if (regionData.code === code) {
        return regionData;
      }
    }
    return null;
  },

  getFlagFromLocation(location) {
    const code = this.parseLocation(location);
    if (code) {
      return this.getFlag(code);
    }
    return '🌐'; 
  }
};
