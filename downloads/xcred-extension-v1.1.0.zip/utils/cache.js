/*
 * XCred - Account Transparency for X/Twitter
 * Copyright (c) 2025 Will Power Media LLC. All rights reserved.
 * Unauthorized copying, distribution, or modification is prohibited.
 * https://xcred.org
 */

const XLocationCache = {
  DB_NAME: 'XLocationCache',
  DB_VERSION: 2, 
  STORE_NAME: 'profiles',
  CACHE_DURATION: 24 * 60 * 60 * 1000, 
  ERROR_CACHE_DURATION: 30 * 60 * 1000, 

  MAX_STORAGE_MB: 50,
  MAX_ENTRIES: 5000, 
  EVICTION_BATCH_SIZE: 500, 

  db: null,

  memoryCache: new Map(),
  MEMORY_CACHE_MAX: 200, 

  useRemoteCache: true, 

  isValidCacheEntry(data) {
    if (!data) return false;

    if (data.isGovernmentVerified) {
      return true;
    }

    if (data.createdAt) {
      return true;
    }

    if (data.connectedVia) {
      return true;
    }

    if (data.accountBasedIn) {
      return true;
    }

    if (data.tier !== null && data.tier !== undefined) {
      return true;
    }

    if (data.error && data.displayName && data.displayName !== data.username) {
      return true;
    }

    return false;
  },

  async init() {
    if (this.db) return this.db;

    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);

      request.onerror = () => {
        reject(request.error);
      };

      request.onsuccess = () => {
        this.db = request.result;
        resolve(this.db);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        const oldVersion = event.oldVersion;

        let store;
        if (!db.objectStoreNames.contains(this.STORE_NAME)) {
          store = db.createObjectStore(this.STORE_NAME, { keyPath: 'username' });
          store.createIndex('timestamp', 'timestamp', { unique: false });
          store.createIndex('lastAccessed', 'lastAccessed', { unique: false });
        } else {
          
          store = event.target.transaction.objectStore(this.STORE_NAME);
        }

        if (oldVersion < 2 && store && !store.indexNames.contains('lastAccessed')) {
          store.createIndex('lastAccessed', 'lastAccessed', { unique: false });
        }
      };
    });
  },

  async get(username) {
    const key = username.toLowerCase();

    if (this.memoryCache.has(key)) {
      const memData = this.memoryCache.get(key);
      const age = Date.now() - memData.timestamp;
      const maxAge = memData.error ? this.ERROR_CACHE_DURATION : this.CACHE_DURATION;

      if (age <= maxAge) {
        
        if (!this.isValidCacheEntry(memData)) {
          this.memoryCache.delete(key);
          this.delete(username); 
          return null;
        }
        
        memData.lastAccessed = Date.now();
        memData._cacheSource = 'memory';
        return memData;
      } else {
        this.memoryCache.delete(key);
      }
    }

    await this.init();

    const indexedDBResult = await new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);
      const request = store.get(key);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const data = request.result;

        if (!data) {
          resolve(null);
          return;
        }

        const age = Date.now() - data.timestamp;
        const maxAge = data.error ? this.ERROR_CACHE_DURATION : this.CACHE_DURATION;

        if (age > maxAge) {
          this.delete(username);
          resolve(null);
          return;
        }

        if (!this.isValidCacheEntry(data)) {
          this.delete(username);
          resolve(null);
          return;
        }

        data.lastAccessed = Date.now();
        store.put(data);

        this.addToMemoryCache(key, data);

        data._cacheSource = 'indexeddb';
        resolve(data);
      };
    });

    if (indexedDBResult) {
      return indexedDBResult;
    }

    if (this.useRemoteCache && typeof XLocationRemote !== 'undefined' && XLocationRemote.isEnabled) {
      try {
        const remoteData = await XLocationRemote.get(username);
        if (remoteData && this.isValidCacheEntry(remoteData)) {
          
          this.addToMemoryCache(key, remoteData);
          await this.setLocal(username, remoteData); 

          return remoteData;
        }
      } catch (e) {
        
      }
    }

    return null;
  },

  addToMemoryCache(key, data) {
    
    if (this.memoryCache.size >= this.MEMORY_CACHE_MAX) {
      const firstKey = this.memoryCache.keys().next().value;
      this.memoryCache.delete(firstKey);
    }
    this.memoryCache.set(key, data);
  },

  async set(username, profileData, skipOnRateLimit = false) {
    
    if (skipOnRateLimit && profileData.rateLimited) {
      return;
    }

    const key = username.toLowerCase();
    const now = Date.now();

    const data = {
      username: key,
      ...profileData,
      timestamp: now,
      lastAccessed: now
    };

    if (!this.isValidCacheEntry(data) && !profileData.error) {
      return;
    }

    this.addToMemoryCache(key, data);

    await this.init();

    if (Math.random() < 0.05) { 
      this.checkAndEvict();
    }

    await new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);

      const request = store.put(data);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });

    if (this.useRemoteCache && typeof XLocationRemote !== 'undefined' && XLocationRemote.isEnabled) {
      XLocationRemote.set(username, profileData).catch(e => {
        
      });
    }
  },

  async setLocal(username, profileData) {
    const key = username.toLowerCase();
    const now = Date.now();

    const data = {
      username: key,
      ...profileData,
      timestamp: now,
      lastAccessed: now
    };

    await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);

      const request = store.put(data);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  },

  async delete(username) {
    await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);
      const request = store.delete(username.toLowerCase());

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  },

  async clear() {
    await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);
      const request = store.clear();

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  },

  async cleanup() {
    await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);
      const index = store.index('timestamp');
      const expiredTime = Date.now() - this.CACHE_DURATION;
      const range = IDBKeyRange.upperBound(expiredTime);

      const request = index.openCursor(range);

      request.onerror = () => reject(request.error);
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        } else {
          resolve();
        }
      };
    });
  },

  async checkAndEvict() {
    try {
      await this.init();

      const count = await this.getEntryCount();

      if (count > this.MAX_ENTRIES) {
        await this.evictLRU(this.EVICTION_BATCH_SIZE);
      }

      if (navigator.storage && navigator.storage.estimate) {
        const estimate = await navigator.storage.estimate();
        const usedMB = (estimate.usage || 0) / (1024 * 1024);

        if (usedMB > this.MAX_STORAGE_MB) {
          await this.evictLRU(this.EVICTION_BATCH_SIZE);
        }
      }
    } catch (e) {
      
    }
  },

  async getEntryCount() {
    await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.STORE_NAME], 'readonly');
      const store = transaction.objectStore(this.STORE_NAME);
      const request = store.count();

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
    });
  },

  async evictLRU(count) {
    await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);

      let index;
      try {
        index = store.index('lastAccessed');
      } catch (e) {
        index = store.index('timestamp');
      }

      let deleted = 0;
      const request = index.openCursor();

      request.onerror = () => reject(request.error);
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor && deleted < count) {
          
          this.memoryCache.delete(cursor.value.username);
          cursor.delete();
          deleted++;
          cursor.continue();
        } else {
          resolve(deleted);
        }
      };
    });
  },

  async getStats() {
    await this.init();

    const count = await this.getEntryCount();
    let storageMB = 0;

    if (navigator.storage && navigator.storage.estimate) {
      const estimate = await navigator.storage.estimate();
      storageMB = (estimate.usage || 0) / (1024 * 1024);
    }

    return {
      entries: count,
      maxEntries: this.MAX_ENTRIES,
      storageMB: storageMB.toFixed(2),
      maxStorageMB: this.MAX_STORAGE_MB,
      memoryCacheSize: this.memoryCache.size
    };
  }
};

XLocationCache.init().catch(() => {
  
});
