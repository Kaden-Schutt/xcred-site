/*
 * XCred - Account Transparency for X/Twitter
 * Copyright (c) 2025 Will Power Media LLC. All rights reserved.
 * Unauthorized copying, distribution, or modification is prohibited.
 * https://xcred.org
 */

const DEFAULT_SETTINGS = {
  enabled: true,
  showFlags: true,
  showBorders: true,
  debugMode: false
};

chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[XCred] Extension installed:', details.reason);

  if (details.reason === 'install') {
    
    await chrome.storage.sync.set({ xlocation_settings: DEFAULT_SETTINGS });
    console.log('[XCred] Default settings initialized');
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[XCred] Received message:', message.type);

  switch (message.type) {
    case 'GET_SETTINGS':
      chrome.storage.sync.get(['xlocation_settings'], (result) => {
        sendResponse(result.xlocation_settings || DEFAULT_SETTINGS);
      });
      return true; 

    case 'SAVE_SETTINGS':
      chrome.storage.sync.set({ xlocation_settings: message.settings }, () => {
        sendResponse({ success: true });
      });
      return true;

    case 'CLEAR_CACHE':
      
      chrome.tabs.query({ url: ['https:
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, { type: 'CLEAR_CACHE' });
        });
        sendResponse({ success: true });
      });
      return true;

    case 'GET_STATS':
      
      sendResponse({
        profilesProcessed: 0,
        cacheHits: 0,
        cacheMisses: 0
      });
      return true;

    default:
      console.warn('[XCred] Unknown message type:', message.type);
      sendResponse({ error: 'Unknown message type' });
  }
});

chrome.action.onClicked.addListener((tab) => {
  
  console.log('[XCred] Extension icon clicked');
});

chrome.alarms.create('cleanupCache', {
  periodInMinutes: 60 
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'cleanupCache') {
    console.log('[XCred] Running cache cleanup');
    
    chrome.tabs.query({ url: ['https:
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, { type: 'CLEANUP_CACHE' }).catch(() => {
          
        });
      });
    });
  }
});

console.log('[XCred] Background service worker loaded');
