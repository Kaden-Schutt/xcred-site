# XCred - Internal Repository

**PROPRIETARY - DO NOT DISTRIBUTE**

Copyright (c) 2025 Will Power Media LLC. All rights reserved.

## Workspace

This extension is part of the XCred workspace, which contains:
- **xcred-extension/** (this directory) - Chrome extension source code
- **xcred-site/** - Marketing website (separate repository)
- **webstore-assets/** - Chrome Web Store listing materials
- **dist/** - Distribution archives

See the workspace root README (`../README.md`) for complete workspace documentation.

## Development

1. Load unpacked extension in Chrome: `chrome://extensions/`
2. Enable Developer Mode
3. Click "Load unpacked" and select the `xcred-extension/` directory

## Building for Chrome Web Store

1. Update version in `manifest.json`
2. Zip all files except `.git/`, `README.md`, `.gitignore`, `CLAUDE.md`
3. Upload to Chrome Web Store Developer Dashboard

## Configuration

Supabase credentials are in `utils/supabase.js`

## Extension Structure

```
xcred-extension/
├── manifest.json       # Chrome extension manifest
├── background.js       # Service worker
├── content.js          # Main content script
├── popup.html/js       # Extension popup UI
├── styles.css          # Extension styles
├── icons/              # Extension icons (16, 32, 48, 128)
└── utils/              # Utilities (cache, flags, supabase)
```

## Contact

Kaden Schutt
kaden.schutt@icloud.com

Will Power Media LLC
8817 E Bell Rd Ste 201
Scottsdale, AZ 85260
