/*
 * XCred - Account Transparency for X/Twitter
 * Copyright (c) 2025 Will Power Media LLC. All rights reserved.
 * Unauthorized copying, distribution, or modification is prohibited.
 * https://xcred.org
 */

document.addEventListener('DOMContentLoaded', async () => {

  const detectDarkMode = () => {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  };

  if (detectDarkMode()) {
    document.body.classList.add('dark');
  }

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (e.matches) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  });

  const enabledToggle = document.getElementById('enabled');
  const showFlagsToggle = document.getElementById('showFlags');
  const showBordersToggle = document.getElementById('showBorders');
  const remoteSyncToggle = document.getElementById('remoteSync');
  const remoteStatusEl = document.getElementById('remoteStatus');
  const remoteWarningEl = document.getElementById('remoteWarning');
  const clearCacheBtn = document.getElementById('clearCache');
  const statusEl = document.getElementById('status');

  const loadSettings = async () => {
    try {
      const result = await chrome.storage.sync.get(['xlocation_settings']);
      const settings = result.xlocation_settings || {
        enabled: true,
        showFlags: true,
        showBorders: true,
        remoteSync: true 
      };

      enabledToggle.checked = settings.enabled;
      showFlagsToggle.checked = settings.showFlags;
      showBordersToggle.checked = settings.showBorders;
      remoteSyncToggle.checked = settings.remoteSync !== false; 

      updateRemoteWarning(remoteSyncToggle.checked);

      checkRemoteStatus(remoteSyncToggle.checked);
    } catch (e) {
      console.error('Failed to load settings:', e);
    }
  };

  const saveSettings = async () => {
    const settings = {
      enabled: enabledToggle.checked,
      showFlags: showFlagsToggle.checked,
      showBorders: showBordersToggle.checked,
      remoteSync: remoteSyncToggle.checked
    };

    try {
      await chrome.storage.sync.set({ xlocation_settings: settings });
      showStatus('Settings saved');
    } catch (e) {
      console.error('Failed to save settings:', e);
      showStatus('Failed to save settings', true);
    }
  };

  const handleRemoteSyncChange = async () => {
    const isEnabled = remoteSyncToggle.checked;
    updateRemoteWarning(isEnabled);

    await saveSettings();

    if (isEnabled) {
      showStatus('Syncing cache to remote...');
      
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && (tab.url.includes('x.com') || tab.url.includes('twitter.com'))) {
          chrome.tabs.sendMessage(tab.id, { type: 'SYNC_TO_REMOTE' });
        }
      } catch (e) {
        
      }
    }

    checkRemoteStatus(isEnabled);
  };

  const updateRemoteWarning = (isEnabled) => {
    if (remoteWarningEl) {
      remoteWarningEl.style.display = isEnabled ? 'none' : 'block';
    }
  };

  const checkRemoteStatus = async (isEnabled) => {
    if (!remoteStatusEl) return;

    const iconEl = remoteStatusEl.querySelector('.remote-status-icon');
    const textEl = remoteStatusEl.querySelector('.remote-status-text');

    if (!isEnabled) {
      iconEl.className = 'remote-status-icon disabled';
      textEl.textContent = 'Remote sync disabled';
      return;
    }

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && (tab.url.includes('x.com') || tab.url.includes('twitter.com'))) {
        const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_REMOTE_STATUS' });
        if (response && response.configured) {
          if (response.error) {
            iconEl.className = 'remote-status-icon disconnected';
            textEl.textContent = 'Connection error';
          } else {
            iconEl.className = 'remote-status-icon connected';
            const profileCount = response.totalProfiles || 0;
            textEl.innerHTML = `Connected - <span class="remote-profiles">${formatNumber(profileCount)}</span> profiles in shared cache`;
          }
        } else {
          iconEl.className = 'remote-status-icon disconnected';
          textEl.textContent = 'Not configured - see setup instructions';
        }
      } else {
        iconEl.className = 'remote-status-icon';
        textEl.textContent = 'Open X/Twitter to check status';
      }
    } catch (e) {
      iconEl.className = 'remote-status-icon';
      textEl.textContent = 'Open X/Twitter to check status';
    }
  };

  const formatNumber = (num) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const showStatus = (message, isError = false) => {
    statusEl.textContent = message;
    statusEl.style.color = isError ? '#f4212e' : '#00ba7c';
    statusEl.classList.add('show');

    setTimeout(() => {
      statusEl.classList.remove('show');
    }, 2000);
  };

  const clearCache = async () => {
    try {
      
      await chrome.runtime.sendMessage({ type: 'CLEAR_CACHE' });
      showStatus('Cache cleared');
    } catch (e) {
      console.error('Failed to clear cache:', e);
      showStatus('Failed to clear cache', true);
    }
  };

  enabledToggle.addEventListener('change', saveSettings);
  showFlagsToggle.addEventListener('change', saveSettings);
  showBordersToggle.addEventListener('change', saveSettings);
  remoteSyncToggle.addEventListener('change', handleRemoteSyncChange);
  clearCacheBtn.addEventListener('click', clearCache);

  await loadSettings();
});
