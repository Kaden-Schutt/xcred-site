/**
 * XCred - Popup Script
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Detect dark mode from system preference (popup can't access X's page)
  // Use matchMedia for system dark mode detection
  const detectDarkMode = () => {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  };

  // Apply dark mode class
  if (detectDarkMode()) {
    document.body.classList.add('dark');
  }

  // Listen for system theme changes
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (e.matches) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  });

  // Get DOM elements
  const enabledToggle = document.getElementById('enabled');
  const showFlagsToggle = document.getElementById('showFlags');
  const showBordersToggle = document.getElementById('showBorders');
  const remoteSyncToggle = document.getElementById('remoteSync');
  const remoteStatusEl = document.getElementById('remoteStatus');
  const remoteWarningEl = document.getElementById('remoteWarning');
  const clearCacheBtn = document.getElementById('clearCache');
  const statusEl = document.getElementById('status');

  // Load current settings
  const loadSettings = async () => {
    try {
      const result = await chrome.storage.sync.get(['xlocation_settings']);
      const settings = result.xlocation_settings || {
        enabled: true,
        showFlags: true,
        showBorders: true,
        remoteSync: true // Default to enabled
      };

      enabledToggle.checked = settings.enabled;
      showFlagsToggle.checked = settings.showFlags;
      showBordersToggle.checked = settings.showBorders;
      remoteSyncToggle.checked = settings.remoteSync !== false; // Default true

      // Update warning visibility
      updateRemoteWarning(remoteSyncToggle.checked);

      // Check remote status
      checkRemoteStatus(remoteSyncToggle.checked);
    } catch (e) {
      console.error('Failed to load settings:', e);
    }
  };

  // Save settings
  const saveSettings = async () => {
    const settings = {
      enabled: enabledToggle.checked,
      showFlags: showFlagsToggle.checked,
      showBorders: showBordersToggle.checked,
      remoteSync: remoteSyncToggle.checked
    };

    try {
      await chrome.storage.sync.set({ xlocation_settings: settings });
      showStatus('Settings saved');
    } catch (e) {
      console.error('Failed to save settings:', e);
      showStatus('Failed to save settings', true);
    }
  };

  // Handle remote sync toggle with special behavior
  const handleRemoteSyncChange = async () => {
    const isEnabled = remoteSyncToggle.checked;
    updateRemoteWarning(isEnabled);

    await saveSettings();

    // If re-enabled, notify the user about sync
    if (isEnabled) {
      showStatus('Syncing cache to remote...');
      // Trigger sync in content script
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && (tab.url.includes('x.com') || tab.url.includes('twitter.com'))) {
          chrome.tabs.sendMessage(tab.id, { type: 'SYNC_TO_REMOTE' });
        }
      } catch (e) {
        // Ignore if no active tab
      }
    }

    checkRemoteStatus(isEnabled);
  };

  // Update remote warning visibility
  const updateRemoteWarning = (isEnabled) => {
    if (remoteWarningEl) {
      remoteWarningEl.style.display = isEnabled ? 'none' : 'block';
    }
  };

  // Check remote cache status
  const checkRemoteStatus = async (isEnabled) => {
    if (!remoteStatusEl) return;

    const iconEl = remoteStatusEl.querySelector('.remote-status-icon');
    const textEl = remoteStatusEl.querySelector('.remote-status-text');

    if (!isEnabled) {
      iconEl.className = 'remote-status-icon disabled';
      textEl.textContent = 'Remote sync disabled';
      return;
    }

    // Try to get status from background/content script
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && (tab.url.includes('x.com') || tab.url.includes('twitter.com'))) {
        const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_REMOTE_STATUS' });
        if (response && response.configured) {
          if (response.error) {
            iconEl.className = 'remote-status-icon disconnected';
            textEl.textContent = 'Connection error';
          } else {
            iconEl.className = 'remote-status-icon connected';
            const profileCount = response.totalProfiles || 0;
            textEl.innerHTML = `Connected - <span class="remote-profiles">${formatNumber(profileCount)}</span> profiles in shared cache`;
          }
        } else {
          iconEl.className = 'remote-status-icon disconnected';
          textEl.textContent = 'Not configured - see setup instructions';
        }
      } else {
        iconEl.className = 'remote-status-icon';
        textEl.textContent = 'Open X/Twitter to check status';
      }
    } catch (e) {
      iconEl.className = 'remote-status-icon';
      textEl.textContent = 'Open X/Twitter to check status';
    }
  };

  // Format number with K/M suffix
  const formatNumber = (num) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  // Show status message
  const showStatus = (message, isError = false) => {
    statusEl.textContent = message;
    statusEl.style.color = isError ? '#f4212e' : '#00ba7c';
    statusEl.classList.add('show');

    setTimeout(() => {
      statusEl.classList.remove('show');
    }, 2000);
  };

  // Clear cache
  const clearCache = async () => {
    try {
      // Send message to background script
      await chrome.runtime.sendMessage({ type: 'CLEAR_CACHE' });
      showStatus('Cache cleared');
    } catch (e) {
      console.error('Failed to clear cache:', e);
      showStatus('Failed to clear cache', true);
    }
  };

  // Event listeners
  enabledToggle.addEventListener('change', saveSettings);
  showFlagsToggle.addEventListener('change', saveSettings);
  showBordersToggle.addEventListener('change', saveSettings);
  remoteSyncToggle.addEventListener('change', handleRemoteSyncChange);
  clearCacheBtn.addEventListener('click', clearCache);

  // Load settings on popup open
  await loadSettings();
});
