/*
 * XCred - Account Transparency for X/Twitter
 * Copyright (c) 2025 Will Power Media LLC. All rights reserved.
 * Unauthorized copying, distribution, or modification is prohibited.
 * https://xcred.org
 */

(function() {
  'use strict';

  const XLocation = {
    
    config: {
      enabled: true,
      showFlags: true,
      showBorders: true
    },

    pendingRequests: new Map(),

    requestQueue: [],
    isProcessingQueue: false,
    RATE_LIMIT_DELAY: 500, 
    RATE_LIMIT_PAUSED: false,
    RATE_LIMIT_PAUSE_UNTIL: 0,
    RATE_LIMIT_BASE_PAUSE: 60000, 
    RATE_LIMIT_CURRENT_PAUSE: 60000, 
    RATE_LIMIT_MAX_PAUSE: 300000, 
    RATE_LIMIT_CONSECUTIVE: 0, 

    BATCH_SIZE: 5, 
    BATCH_DELAY: 3000, 
    MAX_QUEUE_SIZE: 50, 

    authToken: null,
    csrfToken: null,

    PUBLIC_BEARER: 'AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',

    TIER_COLORS: {
      1: '#1DA1F2', 
      2: '#17BF63', 
      3: '#FACC15', 
      4: '#FB923C', 
      5: '#EF4444', 
      6: '#9CA3AF', 
      government: '#C0C0C0' 
    },

    DEMOCRAT_AFFILIATES: ['housedems', 'housedemocrats', 'senatedems', 'senatedemocrats', 'democrats', 'thedemocrats'],
    REPUBLICAN_AFFILIATES: ['housegop', 'houserepublicans', 'senategop', 'senaterepublicans', 'republicans', 'gop'],

    FIVE_EYES_COUNTRIES: ['US', 'GB', 'CA', 'AU', 'NZ'],

    ADVERSARY_COUNTRIES: ['RU', 'CN', 'IR', 'KP'],

    BOT_FARM_COUNTRIES: ['IN', 'BD', 'PK', 'PH', 'NG', 'VN', 'ID', 'EG'],

    REGION_RISK: {
      
      'south asia': 'high',
      'eastern europe': 'high',
      'southeast asia': 'medium',
      'middle east': 'medium',
      'africa': 'medium',
      
      'north america': 'low',
      'western europe': 'low',
      'europe': 'low',
      'oceania': 'low',
      'australia': 'low',
      
      'latin america': 'neutral',
      'south america': 'neutral',
      'east asia': 'neutral',
      'asia': 'neutral',
      'asia pacific': 'neutral'
    },

    MAJOR_GEO_COUNTRIES: ['US', 'RU', 'CN', 'IR', 'KP', 'IL', 'UA', 'TW', 'SA'],

    NEIGHBORING_COUNTRIES: {
      'US': ['CA', 'MX'],
      'CA': ['US'],
      'MX': ['US', 'GT', 'BZ'],
      'GB': ['IE'],
      'IE': ['GB'],
      'DE': ['AT', 'CH', 'FR', 'PL', 'NL', 'BE', 'CZ', 'DK'],
      'FR': ['DE', 'ES', 'IT', 'CH', 'BE'],
      'ES': ['PT', 'FR'],
      'PT': ['ES'],
      'IT': ['FR', 'CH', 'AT'],
      'CH': ['DE', 'FR', 'IT', 'AT'],
      'AT': ['DE', 'CH', 'IT', 'HU', 'CZ'],
      'PL': ['DE', 'CZ', 'UA'],
      'UA': ['PL', 'RO', 'HU'],
      'RU': ['UA', 'BY', 'KZ'],
      'CN': ['HK', 'TW', 'KR', 'JP', 'VN'],
      'HK': ['CN'],
      'TW': ['CN'],
      'JP': ['KR'],
      'KR': ['JP'],
      'AU': ['NZ'],
      'NZ': ['AU']
    },

    extractAuthTokens() {
      
      const cookies = document.cookie;
      this.csrfToken = cookies.match(/ct0=([^;]+)/)?.[1] || null;

      const scripts = document.querySelectorAll('script');
      for (const script of scripts) {
        const content = script.textContent || '';
        
        const bearerMatch = content.match(/Bearer\s+(AAAAAAAAAAAAA[A-Za-z0-9%]+)/);
        if (bearerMatch && bearerMatch[1] !== this.PUBLIC_BEARER) {
          this.authToken = bearerMatch[1];
          break;
        }
      }

      if (!this.authToken && window.__INITIAL_STATE__) {
        
        const stateStr = JSON.stringify(window.__INITIAL_STATE__);
        const match = stateStr.match(/Bearer\s+(AAAAAAAAAAAAA[A-Za-z0-9%]+)/);
        if (match) {
          this.authToken = match[1];
        }
      }

      if (!this.authToken) {
        this.authToken = this.PUBLIC_BEARER;
      }

    },

    async init() {
      console.log('[XCred] Initializing...');

      await this.loadSettings();

      if (!this.config.enabled) {
        console.log('[XCred] Extension disabled');
        return;
      }

      this.extractAuthTokens();

      this.processTimeline();

      this.observeTimeline();

      console.log('[XCred] Initialized successfully');
    },

    async loadSettings() {
      try {
        const result = await chrome.storage.sync.get(['xlocation_settings']);
        if (result.xlocation_settings) {
          this.config = { ...this.config, ...result.xlocation_settings };
        }
      } catch (e) {
        console.warn('[XCred] Could not load settings:', e);
      }
    },

    findTweets() {
      return document.querySelectorAll('article[data-testid="tweet"]');
    },

    extractUsername(tweetElement) {
      
      const userLinks = tweetElement.querySelectorAll('a[href^="/"]');

      for (const link of userLinks) {
        const href = link.getAttribute('href');
        
        const match = href.match(/^\/([a-zA-Z0-9_]+)$/);
        if (match && match[1] !== 'home' && match[1] !== 'explore' && match[1] !== 'notifications') {
          
          const isInHeader = link.closest('[data-testid="User-Name"]') !== null;
          if (isInHeader) {
            return match[1];
          }
        }
      }

      const userNameDiv = tweetElement.querySelector('[data-testid="User-Name"]');
      if (userNameDiv) {
        const text = userNameDiv.textContent;
        const atMatch = text.match(/@([a-zA-Z0-9_]+)/);
        if (atMatch) {
          return atMatch[1];
        }
      }

      return null;
    },

    findInjectionTarget(tweetElement) {

      const avatarByTestId = tweetElement.querySelector('[data-testid="Tweet-User-Avatar"]');
      if (avatarByTestId) {
        return avatarByTestId;
      }

      const profileLinks = tweetElement.querySelectorAll('a[href^="/"]');
      for (const link of profileLinks) {
        const href = link.getAttribute('href');
        
        if (href && /^\/[a-zA-Z0-9_]+$/.test(href)) {
          
          const hasImage = link.querySelector('img') ||
                          link.querySelector('[style*="background-image"]') ||
                          link.querySelector('div[style*="background"]');
          if (hasImage) {
            return link;
          }
        }
      }

      const images = tweetElement.querySelectorAll('img');
      for (const img of images) {
        const src = img.getAttribute('src') || '';
        
        if (src.includes('profile_images')) {
          
          const container = img.closest('a') || img.parentElement;
          if (container) {
            return container;
          }
        }
      }

      return null;
    },

    processTimeline() {
      const tweets = this.findTweets();
      tweets.forEach(tweet => this.processTweet(tweet));
    },

    async processTweet(tweetElement) {
      
      if (tweetElement.querySelector('.xlocation-indicator')) {
        return;
      }

      const username = this.extractUsername(tweetElement);
      if (!username) {
        return;
      }

      try {
        const cached = await XLocationCache.get(username);
        if (cached && !cached.rateLimited) {
          this.injectIndicator(tweetElement, cached);
          return;
        }
      } catch (e) {
        
      }

      if (this.pendingRequests.has(username)) {
        
        this.pendingRequests.get(username).elements.push(tweetElement);
        return;
      }

      this.queueProfileFetch(username, tweetElement);
    },

    queueProfileFetch(username, tweetElement) {
      
      if (this.requestQueue.length >= this.MAX_QUEUE_SIZE) {
        return;
      }

      if (this.requestQueue.includes(username)) {
        return;
      }

      this.pendingRequests.set(username, {
        elements: [tweetElement]
      });

      this.requestQueue.push(username);
      this.processRequestQueue();
    },

    async processRequestQueue() {
      if (this.isProcessingQueue || this.requestQueue.length === 0) {
        return;
      }

      if (this.RATE_LIMIT_PAUSED && Date.now() < this.RATE_LIMIT_PAUSE_UNTIL) {
        
        setTimeout(() => this.processRequestQueue(), this.RATE_LIMIT_PAUSE_UNTIL - Date.now() + 100);
        return;
      }

      if (this.RATE_LIMIT_PAUSED && Date.now() >= this.RATE_LIMIT_PAUSE_UNTIL) {
        this.RATE_LIMIT_PAUSED = false;
      }

      this.isProcessingQueue = true;

      while (this.requestQueue.length > 0) {
        
        if (this.RATE_LIMIT_PAUSED) {
          this.isProcessingQueue = false;
          this.processRequestQueue(); 
          return;
        }

        const batchSize = Math.min(this.BATCH_SIZE, this.requestQueue.length);

        for (let i = 0; i < batchSize; i++) {
          if (this.RATE_LIMIT_PAUSED) break;

          const username = this.requestQueue.shift();
          if (username) {
            await this.fetchProfile(username);
            
            await new Promise(resolve => setTimeout(resolve, this.RATE_LIMIT_DELAY));
          }
        }

        if (this.requestQueue.length > 0 && !this.RATE_LIMIT_PAUSED) {
          await new Promise(resolve => setTimeout(resolve, this.BATCH_DELAY));
        }
      }

      this.isProcessingQueue = false;
    },

    async fetchProfile(username) {
      const pending = this.pendingRequests.get(username);
      if (!pending) return;

      try {
        const cached = await XLocationCache.get(username);
        if (cached && !cached.rateLimited && !cached.error) {
          pending.elements.forEach(element => {
            if (document.contains(element) && !element.querySelector('.xlocation-indicator')) {
              this.injectIndicator(element, cached);
            }
          });
          this.pendingRequests.delete(username);
          return;
        }
      } catch (e) {
        
      }

      try {
        
        let profileData = await this.fetchFromAPI(username);

        if (profileData && profileData.rateLimited) {
          
          try {
            const cached = await XLocationCache.get(username);
            if (cached && !cached.rateLimited && !cached.error) {
              pending.elements.forEach(element => {
                if (document.contains(element)) {
                  this.injectIndicator(element, cached);
                }
              });
              this.pendingRequests.delete(username);
              return;
            }
          } catch (e) {
            
          }

          this.requestQueue.push(username);
          return; 
        }

        if (!profileData) {
          profileData = {
            username: username,
            location: null,
            locationCountry: null,
            error: true
          };
        }

        await XLocationCache.set(username, profileData, true);

        pending.elements.forEach(element => {
          if (document.contains(element)) {
            this.injectIndicator(element, profileData);
          }
        });

        this.pendingRequests.delete(username);

      } catch (e) {
        
        await XLocationCache.set(username, {
          username: username,
          location: null,
          locationCountry: null,
          error: true
        });
        this.pendingRequests.delete(username);
      }
    },

    async fetchFromAPI(username) {
      try {
        
        if (!this.csrfToken) {
          this.extractAuthTokens();
        }

        if (!this.csrfToken) {
          return null;
        }

        const variables = JSON.stringify({
          screenName: username
        });

        const response = await fetch(
          `https://x.com/i/api/graphql/XRqGa7EeokUU5kppkh13EA/AboutAccountQuery?variables=${encodeURIComponent(variables)}`,
          {
            credentials: 'include',
            headers: {
              'authorization': `Bearer ${this.authToken}`,
              'x-csrf-token': this.csrfToken,
              'x-twitter-active-user': 'yes',
              'x-twitter-auth-type': 'OAuth2Session',
              'x-twitter-client-language': 'en',
              'content-type': 'application/json'
            }
          }
        );

        if (response.status === 429) {
          this.RATE_LIMIT_CONSECUTIVE++;

          this.RATE_LIMIT_CURRENT_PAUSE = Math.min(
            this.RATE_LIMIT_BASE_PAUSE * Math.pow(1.5, this.RATE_LIMIT_CONSECUTIVE - 1),
            this.RATE_LIMIT_MAX_PAUSE
          );

          const pauseSeconds = Math.round(this.RATE_LIMIT_CURRENT_PAUSE / 1000);
          console.warn(`[XCred] Rate limited! (${this.RATE_LIMIT_CONSECUTIVE}x) Pausing for ${pauseSeconds}s...`);

          this.RATE_LIMIT_PAUSED = true;
          this.RATE_LIMIT_PAUSE_UNTIL = Date.now() + this.RATE_LIMIT_CURRENT_PAUSE;
          this.RATE_LIMIT_DELAY = Math.min(this.RATE_LIMIT_DELAY * 1.5, 2000);

          if (typeof XLocationRemote !== 'undefined' && !XLocationRemote.isEnabled && XLocationRemote.isConfigured) {
            XLocationRemote.showRateLimitPrompt();
          }

          return { rateLimited: true };
        }

        if (!response.ok) {
          return null;
        }

        this.RATE_LIMIT_DELAY = 500;
        this.RATE_LIMIT_CONSECUTIVE = 0;
        this.RATE_LIMIT_CURRENT_PAUSE = this.RATE_LIMIT_BASE_PAUSE;

        const data = await response.json();
        return this.parseAPIResponse(data, username);

      } catch (e) {
        return null;
      }
    },

    detectPartyAffiliation(affiliateUsername) {
      if (!affiliateUsername) return null;

      const affiliate = affiliateUsername.toLowerCase();

      for (const keyword of this.DEMOCRAT_AFFILIATES) {
        if (affiliate.includes(keyword)) {
          return 'democrat';
        }
      }

      for (const keyword of this.REPUBLICAN_AFFILIATES) {
        if (affiliate.includes(keyword)) {
          return 'republican';
        }
      }

      return 'other';
    },

    parseAPIResponse(data, username) {
      try {
        
        const user = data?.data?.user_result_by_screen_name?.result;
        if (!user) {
          return null;
        }

        const aboutProfile = user.about_profile || {};
        const core = user.core || {};
        const verification = user.verification || {};

        const isGovernmentVerified = verification.verified_type === 'Government';
        const affiliateUsername = aboutProfile.affiliate_username || null;
        const party = isGovernmentVerified ? this.detectPartyAffiliation(affiliateUsername) : null;

        const isBusinessVerified = verification.verified_type === 'Business';
        const isBlueVerified = user.is_blue_verified || (verification.verified && !isGovernmentVerified && !isBusinessVerified);

        const profileData = {
          username: username,
          location: null,
          locationCountry: null,
          displayLocation: null, 
          accountBasedIn: null,
          connectedVia: null,
          vpnDetected: false,
          locationAccurate: true,
          usernameChanges: 0,
          verified: isBlueVerified || isBusinessVerified || isGovernmentVerified,
          isBlueVerified: isBlueVerified,
          isBusinessVerified: isBusinessVerified,
          displayName: core.name || username,
          
          createdAt: aboutProfile.created_at || user.created_at || null,
          screenName: core.screen_name || username,
          
          isGovernmentVerified: isGovernmentVerified,
          verifiedType: verification.verified_type || null,
          party: party,
          affiliateUsername: affiliateUsername,
          
          tier: null
        };

        if (aboutProfile) {
          
          profileData.accountBasedIn = aboutProfile.account_based_in || null;

          profileData.connectedVia = aboutProfile.source || null;

          profileData.locationAccurate = aboutProfile.location_accurate !== false;
          profileData.vpnDetected = aboutProfile.location_accurate === false;

          if (aboutProfile.username_changes) {
            profileData.usernameChanges = parseInt(aboutProfile.username_changes.count, 10) || 0;
          }
        }

        if (profileData.accountBasedIn) {
          profileData.location = profileData.accountBasedIn;
          profileData.locationCountry = XLocationFlags.parseLocation(profileData.accountBasedIn);
        }

        profileData.tier = this.calculateTier(profileData);

        return profileData;

      } catch (e) {
        return null;
      }
    },

    extractAppStoreCountry(connectedVia) {
      if (!connectedVia) return null;
      
      return XLocationFlags.parseLocation(connectedVia);
    },

    isNeighboringCountries(country1, country2) {
      if (!country1 || !country2) return false;
      const neighbors = this.NEIGHBORING_COUNTRIES[country1];
      return neighbors && neighbors.includes(country2);
    },

    isMajorGeopoliticalMismatch(accountCountry, appStoreCountry) {
      if (!accountCountry || !appStoreCountry) return false;

      if (accountCountry === appStoreCountry) return false;

      const accountIsMajor = this.MAJOR_GEO_COUNTRIES.includes(accountCountry);
      const appStoreIsMajor = this.MAJOR_GEO_COUNTRIES.includes(appStoreCountry);

      if (accountIsMajor && appStoreIsMajor && accountCountry !== appStoreCountry) {
        return true;
      }

      if ((accountIsMajor || appStoreIsMajor) && !this.isNeighboringCountries(accountCountry, appStoreCountry)) {
        return true;
      }

      return false;
    },

    calculateAccountAge(createdAt) {
      if (!createdAt) return 0;

      try {
        const created = new Date(createdAt);
        if (isNaN(created.getTime())) return 0;

        const now = new Date();
        const ageMs = now - created;
        const ageYears = ageMs / (1000 * 60 * 60 * 24 * 365.25);
        return Math.max(0, ageYears);
      } catch (e) {
        return 0;
      }
    },

    getPlatformType(connectedVia) {
      if (!connectedVia) return 'web';
      const lower = connectedVia.toLowerCase();
      if (lower.includes('app store')) return 'ios';
      if (lower.includes('android')) return 'android';
      return 'web';
    },

    isFiveEyes(countryCode) {
      return countryCode && this.FIVE_EYES_COUNTRIES.includes(countryCode);
    },

    isAdversaryOrigin(countryCode, accountBasedIn) {
      if (countryCode && this.ADVERSARY_COUNTRIES.includes(countryCode)) {
        return true;
      }
      
      if (accountBasedIn) {
        const lower = accountBasedIn.toLowerCase();
        if (lower.includes('russia') || lower.includes('china') || lower.includes('iran') || lower.includes('north korea')) {
          return true;
        }
      }
      return false;
    },

    isBotFarmOrigin(countryCode, accountBasedIn) {
      if (countryCode && this.BOT_FARM_COUNTRIES.includes(countryCode)) {
        return true;
      }
      
      if (accountBasedIn) {
        const lower = accountBasedIn.toLowerCase();
        const risk = this.REGION_RISK[lower];
        if (risk === 'high') return true;
      }
      return false;
    },

    getRegionRisk(accountBasedIn) {
      if (!accountBasedIn) return null;
      const lower = accountBasedIn.toLowerCase().trim();
      return this.REGION_RISK[lower] || null;
    },

    checkRegionalMismatch(accountBasedIn, connectedVia) {
      const accountRisk = this.getRegionRisk(accountBasedIn);
      const appStoreRisk = this.getRegionRisk(connectedVia);

      if (accountRisk && appStoreRisk) {
        const isMismatch = (accountRisk === 'high' && appStoreRisk === 'low') ||
                          (accountRisk === 'medium' && appStoreRisk === 'low');
        return { isMismatch, accountRisk, appStoreRisk };
      }

      return { isMismatch: false, accountRisk, appStoreRisk };
    },

    calculateCredibilityScore(profileData) {
      const factors = [];
      let score = 0;
      let instantTier = null; 

      const connectedVia = profileData.connectedVia || '';
      const accountBasedIn = profileData.accountBasedIn || '';
      const platform = this.getPlatformType(connectedVia);
      const hasVPN = profileData.vpnDetected;
      const usernameChanges = profileData.usernameChanges || 0;
      const accountCountry = profileData.locationCountry;
      const appStoreCountry = this.extractAppStoreCountry(connectedVia);
      const accountAge = this.calculateAccountAge(profileData.createdAt);

      const locationMatch = accountCountry && appStoreCountry && accountCountry === appStoreCountry;
      const isNeighbor = accountCountry && appStoreCountry && this.isNeighboringCountries(accountCountry, appStoreCountry);
      const bothFiveEyes = this.isFiveEyes(accountCountry) && this.isFiveEyes(appStoreCountry);
      const isAdversary = this.isAdversaryOrigin(accountCountry, accountBasedIn);
      const isBotFarm = this.isBotFarmOrigin(accountCountry, accountBasedIn);
      const regionalMismatch = this.checkRegionalMismatch(accountBasedIn, connectedVia);

      if (isAdversary && (platform === 'android' || platform === 'web') && hasVPN) {
        instantTier = 5;
        factors.push({ name: 'ADVERSARY + Android/Web + VPN', value: 'NUKE', type: 'critical' });
        debug.push('*** INSTANT TIER 5: Adversary nation + Android/Web + VPN ***');
      }

      if (platform === 'ios') {
        score += 1;
        factors.push({ name: 'iOS platform', value: +1 });
      } else if (platform === 'web') {
        score -= 1;
        factors.push({ name: 'Web platform (less trusted)', value: -1 });
      }

      if (locationMatch) {
        if (platform === 'ios') {
          score += 3;
          factors.push({ name: 'iOS + geo match', value: +3 });
        } else if (platform === 'android') {
          score += 2;
          factors.push({ name: 'Android + geo match', value: +2 });
        } else {
          score += 1;
          factors.push({ name: 'Web + geo match', value: +1 });
        }
      } else if (isNeighbor && !hasVPN) {
        score += 1;
        factors.push({ name: 'Neighbor country (no VPN)', value: +1 });
      }

      if (profileData.isBusinessVerified) {
        score += 3;
        factors.push({ name: 'Business verified', value: +3 });
      } else if (profileData.isBlueVerified) {
        score += 2;
        factors.push({ name: 'Blue verified', value: +2 });
      }

      if (accountAge >= 5) {
        score += 3;
        factors.push({ name: 'Account 5yr+', value: +3 });
      } else if (accountAge >= 3) {
        score += 2;
        factors.push({ name: 'Account 3-5yr', value: +2 });
      } else if (accountAge >= 1) {
        score += 1;
        factors.push({ name: 'Account 1-3yr', value: +1 });
      }

      if (hasVPN) {
        if (locationMatch && platform === 'ios') {
          
          score -= 1;
          factors.push({ name: 'VPN (iOS + geo match)', value: -1 });
        } else if (bothFiveEyes) {
          
          score -= 1;
          factors.push({ name: 'VPN (Five Eyes corridor)', value: -1 });
        } else if (platform === 'ios') {
          
          score -= 2;
          factors.push({ name: 'VPN (iOS + mismatch)', value: -2 });
        } else if (isBotFarm) {
          
          score -= 4;
          factors.push({ name: 'VPN (bot farm + Android/Web)', value: -4 });
        } else {
          
          score -= 3;
          factors.push({ name: 'VPN (Android/Web + mismatch)', value: -3 });
        }
      }

      if (!hasVPN && !locationMatch && appStoreCountry) {
        if (platform === 'ios') {
          
          factors.push({ name: 'Geo mismatch (iOS, no VPN)', value: 0, note: 'likely expat/traveler' });
        } else if (platform === 'android') {
          score -= 1;
          factors.push({ name: 'Geo mismatch (Android, no VPN)', value: -1 });
        } else {
          score -= 2;
          factors.push({ name: 'Geo mismatch (Web, no VPN)', value: -2 });
        }
      }

      if (regionalMismatch.isMismatch) {
        score -= 2;
        factors.push({ name: `Regional mismatch (${regionalMismatch.accountRisk} → ${regionalMismatch.appStoreRisk})`, value: -2 });
      }

      if (usernameChanges >= 10) {
        score -= 3;
        factors.push({ name: `${usernameChanges} username changes`, value: -3 });
      } else if (usernameChanges >= 6) {
        score -= 2;
        factors.push({ name: `${usernameChanges} username changes`, value: -2 });
      } else if (usernameChanges >= 3) {
        score -= 1;
        factors.push({ name: `${usernameChanges} username changes`, value: -1 });
      }

      return { total: score, factors, instantTier, accountAge };
    },

    calculateTier(profileData) {
      
      if (profileData.isGovernmentVerified) {
        return 'government';
      }

      if (!profileData.locationCountry && !profileData.accountBasedIn && !profileData.connectedVia) {
        return 6;
      }

      const { total: score, instantTier } = this.calculateCredibilityScore(profileData);

      if (instantTier !== null) {
        return instantTier;
      }

      if (score >= 6) {
        return 1;
      } else if (score >= 4) {
        return 2;
      } else if (score >= 2) {
        return 3;
      } else if (score >= 0) {
        return 4;
      } else {
        return 5;
      }
    },

    injectIndicator(tweetElement, profileData) {
      
      if (tweetElement.querySelector('.xlocation-indicator')) {
        return;
      }

      const avatarElement = this.findInjectionTarget(tweetElement);
      if (!avatarElement) {
        return;
      }

      const indicator = this.createIndicator(profileData);

      const avatarContainer = avatarElement.parentElement;

      if (avatarContainer) {
        
        avatarElement.insertAdjacentElement('afterend', indicator);
      } else {
        
        avatarElement.parentNode.insertBefore(indicator, avatarElement.nextSibling);
      }
    },

    GOV_ICONS: {
      democrat: 'https:
      republican: 'https:
      other: null 
    },

    getGovernmentIcon(party) {
      switch (party) {
        case 'democrat':
          return {
            url: this.GOV_ICONS.democrat,
            emoji: '🫏',
            bgColor: '#0052A5' 
          };
        case 'republican':
          return {
            url: this.GOV_ICONS.republican,
            emoji: '🐘',
            bgColor: '#BF0A30' 
          };
        case 'other':
        default:
          return {
            url: null,
            emoji: '🏛️',
            bgColor: '#C0C0C0' 
          };
      }
    },

    getTierDescription(tier) {
      
      const normalizedTier = tier === 'government' ? tier : parseInt(tier, 10);
      switch (normalizedTier) {
        case 1:
          return 'Highest Credibility - iOS + Location Match + Clean History';
        case 2:
          return 'High Credibility - Verified Location Match';
        case 3:
          return 'Medium Credibility - Minor Issues Detected';
        case 4:
          return 'Low Credibility - Multiple Red Flags';
        case 5:
          return 'SUSPICIOUS - Major Location Mismatch';
        case 6:
          return 'Unknown - No Location Data';
        case 'government':
          return 'Government Verified Account';
        default:
          return 'Unknown Credibility';
      }
    },

    createIndicator(profileData) {
      const indicator = document.createElement('span');
      indicator.className = 'xlocation-indicator';

      const rawTier = profileData.tier || this.calculateTier(profileData);
      
      const tier = rawTier === 'government' ? rawTier : parseInt(rawTier, 10);

      indicator.classList.add(`xlocation-tier-${tier}`);

      const tierColor = this.TIER_COLORS[tier] || this.TIER_COLORS[6];
      indicator.style.borderColor = tierColor;

      if (profileData.isGovernmentVerified) {
        const govIcon = this.getGovernmentIcon(profileData.party);
        indicator.classList.add('xlocation-government');
        indicator.style.backgroundColor = govIcon.bgColor;
        indicator.style.borderColor = govIcon.bgColor;

        if (govIcon.url) {
          
          const iconImg = document.createElement('img');
          iconImg.src = govIcon.url;
          iconImg.alt = profileData.party;
          iconImg.className = 'xlocation-gov-icon';
          iconImg.onerror = () => {
            
            iconImg.remove();
            indicator.textContent = govIcon.emoji;
          };
          indicator.appendChild(iconImg);
        } else {
          
          indicator.textContent = govIcon.emoji;
        }
      }
      
      else if (this.config.showFlags) {
        const flagUrl = profileData.locationCountry
          ? XLocationFlags.getFlagUrl(profileData.locationCountry)
          : null;

        if (flagUrl) {
          
          const flagImg = document.createElement('img');
          flagImg.src = flagUrl;
          flagImg.alt = profileData.locationCountry;
          flagImg.className = 'xlocation-flag-img';
          flagImg.onerror = () => {
            
            flagImg.remove();
            indicator.textContent = XLocationFlags.getFlagEmoji(profileData.locationCountry) || '🌐';
          };
          indicator.appendChild(flagImg);
        } else {
          
          indicator.textContent = XLocationFlags.getFlagEmoji(profileData.locationCountry) || '🌐';
        }
      } else {
        
        indicator.textContent = '🌐';
      }

      const tooltipText = this.getTooltipText(profileData);
      indicator.setAttribute('title', tooltipText);
      indicator.setAttribute('data-xlocation-tooltip', tooltipText);

      indicator.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.showDetailedInfo(profileData, indicator);
      });

      return indicator;
    },

    getCredibilityClass(profileData) {
      
      if (profileData.error) {
        return 'unknown';
      }

      if (profileData.vpnDetected || profileData.locationAccurate === false) {
        return 'vpn'; 
      }

      if (profileData.accountBasedIn) {
        return 'match'; 
      }

      if (profileData.connectedVia) {
        return 'connection'; 
      }

      return 'unknown';
    },

    getTooltipText(profileData) {
      const parts = [];
      const tier = profileData.tier || this.calculateTier(profileData);

      if (profileData.isGovernmentVerified) {
        parts.push('✓ Government Verified Account');
        if (profileData.party === 'democrat') {
          parts.push('Affiliation: Democratic Party');
        } else if (profileData.party === 'republican') {
          parts.push('Affiliation: Republican Party');
        } else if (profileData.affiliateUsername) {
          parts.push(`Affiliate: @${profileData.affiliateUsername}`);
        }
        return parts.join('\n');
      }

      parts.push(this.getTierDescription(tier));

      if (profileData.vpnDetected || profileData.locationAccurate === false) {
        parts.push('⚠ VPN/Proxy Detected');
      }

      if (profileData.accountBasedIn) {
        parts.push(`Account based in: ${profileData.accountBasedIn}`);
      }

      if (profileData.connectedVia) {
        parts.push(`Connected via: ${profileData.connectedVia}`);
      }

      if (profileData.usernameChanges > 0) {
        parts.push(`Username changes: ${profileData.usernameChanges}`);
      }

      if (parts.length === 1) {
        return 'No location data available';
      }

      return parts.join('\n');
    },

    isXDarkMode() {
      
      const body = document.body;
      const bgColor = window.getComputedStyle(body).backgroundColor;

      const match = bgColor.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
      if (match) {
        const [, r, g, b] = match.map(Number);
        
        const brightness = (r + g + b) / 3;
        return brightness < 128;
      }

      return document.documentElement.classList.contains('dark') ||
             document.body.classList.contains('dark') ||
             document.documentElement.getAttribute('data-theme') === 'dark';
    },

    showDetailedInfo(profileData, indicator) {
      
      const existing = document.querySelector('.xlocation-popup');
      if (existing) {
        existing.remove();
      }

      const popup = document.createElement('div');
      popup.className = 'xlocation-popup';

      if (this.isXDarkMode()) {
        popup.classList.add('xlocation-dark');
      }

      const rawTier = profileData.tier || this.calculateTier(profileData);
      
      const tier = rawTier === 'government' ? rawTier : parseInt(rawTier, 10);
      const tierColor = this.TIER_COLORS[tier] || this.TIER_COLORS[6];
      let statusText = '';
      let statusClass = '';

      if (profileData.isGovernmentVerified) {
        statusText = 'Government Verified';
        statusClass = 'xlocation-status-government';

        let partyText = '';
        const govIcon = this.getGovernmentIcon(profileData.party);
        if (profileData.party === 'democrat') {
          partyText = `<div class="xlocation-popup-party xlocation-party-democrat">
            <img src="${govIcon.url}" alt="Democrat" class="xlocation-party-icon-img" onerror="this.outerHTML='🫏'">
            <span>Democratic Party</span>
          </div>`;
        } else if (profileData.party === 'republican') {
          partyText = `<div class="xlocation-popup-party xlocation-party-republican">
            <img src="${govIcon.url}" alt="Republican" class="xlocation-party-icon-img" onerror="this.outerHTML='🐘'">
            <span>Republican Party</span>
          </div>`;
        } else if (profileData.affiliateUsername) {
          partyText = `<div class="xlocation-popup-row"><strong>Affiliate</strong>@${this.escapeHtml(profileData.affiliateUsername)}</div>`;
        }

        popup.innerHTML = `
          <div class="xlocation-popup-header">
            <span class="xlocation-popup-title">Government Account</span>
            <span class="xlocation-popup-close">&times;</span>
          </div>
          <div class="xlocation-popup-status ${statusClass}">${statusText}</div>
          ${partyText}
          <div class="xlocation-popup-content">
            ${profileData.usernameChanges > 0 ? `<div class="xlocation-popup-row"><strong>Username changes</strong>${profileData.usernameChanges}</div>` : ''}
          </div>
          <div class="xlocation-popup-footer">
            This account has been verified by X as an official government account.
          </div>
        `;
      } else {
        
        switch (tier) {
          case 1:
            statusText = 'Highest Credibility';
            statusClass = 'xlocation-status-tier1';
            break;
          case 2:
            statusText = 'High Credibility';
            statusClass = 'xlocation-status-tier2';
            break;
          case 3:
            statusText = 'Medium Credibility';
            statusClass = 'xlocation-status-tier3';
            break;
          case 4:
            statusText = 'Low Credibility';
            statusClass = 'xlocation-status-tier4';
            break;
          case 5:
            statusText = 'SUSPICIOUS';
            statusClass = 'xlocation-status-tier5';
            break;
          default:
            statusText = 'No Location Data';
            statusClass = 'xlocation-status-tier6';
        }

        const isVpn = profileData.vpnDetected || profileData.locationAccurate === false;

        const scoreData = this.calculateCredibilityScore(profileData);
        const accountAge = scoreData.accountAge;
        const ageDisplay = accountAge >= 1 ? `${Math.floor(accountAge)}yr` : `${Math.floor(accountAge * 12)}mo`;

        let factorsHtml = '';
        if (scoreData.factors.length > 0) {
          const factorChips = scoreData.factors.map(f => {
            
            if (f.type === 'critical') {
              return `<span class="xlocation-factor critical">${f.name}</span>`;
            }
            
            if (f.value === 0 && f.note) {
              return `<span class="xlocation-factor neutral">${f.name}</span>`;
            }
            
            const valueStr = typeof f.value === 'number' ? (f.value >= 0 ? `+${f.value}` : `${f.value}`) : f.value;
            const className = f.value > 0 ? 'positive' : (f.value < 0 ? 'negative' : 'neutral');
            return `<span class="xlocation-factor ${className}">${valueStr} ${f.name}</span>`;
          }).join('');

          factorsHtml = `
            <div class="xlocation-popup-score">
              <div class="xlocation-popup-row"><strong>Credibility Score</strong>${scoreData.instantTier ? 'OVERRIDE' : (scoreData.total >= 0 ? '+' : '') + scoreData.total}</div>
              <div class="xlocation-score-factors">
                ${factorChips}
              </div>
            </div>
          `;
        }

        popup.innerHTML = `
          <div class="xlocation-popup-header">
            <span class="xlocation-popup-title">Location Info</span>
            <span class="xlocation-popup-close">&times;</span>
          </div>
          <div class="xlocation-popup-status ${statusClass}" style="border-left: 4px solid ${tierColor};">${statusText}</div>
          ${isVpn ? `<div class="xlocation-popup-vpn-warning">
            <strong>⚠ Warning:</strong> X has indicated this account may be connecting via a proxy or VPN, which may change the displayed location.
          </div>` : ''}
          <div class="xlocation-popup-content">
            ${profileData.accountBasedIn ? `<div class="xlocation-popup-row"><strong>Account based in</strong>${this.escapeHtml(profileData.accountBasedIn)}</div>` : ''}
            ${profileData.connectedVia ? `<div class="xlocation-popup-row"><strong>Connected via</strong>${this.escapeHtml(profileData.connectedVia)}</div>` : ''}
            ${profileData.createdAt ? `<div class="xlocation-popup-row"><strong>Account age</strong>${ageDisplay}</div>` : ''}
            ${profileData.usernameChanges > 0 ? `<div class="xlocation-popup-row"><strong>Username changes</strong>${profileData.usernameChanges}</div>` : ''}
            ${profileData.isBlueVerified ? `<div class="xlocation-popup-row"><strong>Verification</strong>Blue verified</div>` : ''}
            ${profileData.isBusinessVerified ? `<div class="xlocation-popup-row"><strong>Verification</strong>Business verified</div>` : ''}
          </div>
          ${factorsHtml}
          <div class="xlocation-popup-footer">
            Data from X's account transparency info
          </div>
        `;
      }

      const rect = indicator.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

      popup.style.position = 'absolute';
      popup.style.top = `${rect.bottom + scrollTop + 8}px`;
      popup.style.left = `${rect.left + scrollLeft}px`;

      document.body.appendChild(popup);

      const popupRect = popup.getBoundingClientRect();
      if (popupRect.right > window.innerWidth - 16) {
        popup.style.left = `${window.innerWidth - popupRect.width - 16 + scrollLeft}px`;
      }

      popup.querySelector('.xlocation-popup-close').addEventListener('click', () => {
        popup.remove();
      });

      const closeHandler = (e) => {
        if (!popup.contains(e.target) && e.target !== indicator) {
          popup.remove();
          document.removeEventListener('click', closeHandler);
        }
      };
      setTimeout(() => {
        document.addEventListener('click', closeHandler);
      }, 0);
    },

    escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    },

    observeTimeline() {
      const observer = new MutationObserver((mutations) => {
        let shouldProcess = false;

        for (const mutation of mutations) {
          if (mutation.addedNodes.length > 0) {
            shouldProcess = true;
            break;
          }
        }

        if (shouldProcess) {
          
          if (this.processTimeout) {
            clearTimeout(this.processTimeout);
          }
          this.processTimeout = setTimeout(() => {
            this.processTimeline();
          }, 100);
        }
      });

      const target = document.querySelector('main') || document.body;
      observer.observe(target, {
        childList: true,
        subtree: true
      });
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => XLocation.init());
  } else {
    XLocation.init();
  }

  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && changes.xlocation_settings) {
      XLocation.config = { ...XLocation.config, ...changes.xlocation_settings.newValue };

      if (typeof XLocationRemote !== 'undefined') {
        XLocationRemote.isEnabled = changes.xlocation_settings.newValue.remoteSync !== false;
        XLocationCache.useRemoteCache = XLocationRemote.isEnabled;
      }

      console.log('[XCred] Settings updated');
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'SYNC_TO_REMOTE') {
      
      if (typeof XLocationRemote !== 'undefined' && XLocationRemote.isEnabled) {
        XLocationRemote.syncLocalToRemote().then(() => {
          sendResponse({ success: true });
        }).catch(e => {
          sendResponse({ success: false, error: e.message });
        });
        return true; 
      }
      sendResponse({ success: false, error: 'Remote not enabled' });
    }

    if (message.type === 'GET_REMOTE_STATUS') {
      
      if (typeof XLocationRemote !== 'undefined') {
        const configured = XLocationRemote.isConfigured;
        if (!configured) {
          sendResponse({ configured: false });
          return;
        }

        XLocationRemote.getStats().then(stats => {
          sendResponse({
            configured: true,
            enabled: XLocationRemote.isEnabled,
            totalProfiles: stats.totalProfiles || 0,
            error: stats.error || null
          });
        }).catch(e => {
          sendResponse({
            configured: true,
            enabled: XLocationRemote.isEnabled,
            error: e.message
          });
        });
        return true; 
      }
      sendResponse({ configured: false });
    }

    return false;
  });
})();
